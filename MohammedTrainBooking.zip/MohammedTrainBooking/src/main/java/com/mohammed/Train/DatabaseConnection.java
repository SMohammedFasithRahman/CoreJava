package com.mohammed.Train;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
	
	static Connection con;
	
	public static Connection getConnection() {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/passtrain";
		String us="root";
		String pass="root";
		try {
			Class.forName(driver);
			con=DriverManager.getConnection(url, us, pass);
			
			if(con==null) {
				System.out.println("connection error");
			}
		} catch(Exception e) {
			e.printStackTrace();
			}
		return con;
		
		}
		
	}