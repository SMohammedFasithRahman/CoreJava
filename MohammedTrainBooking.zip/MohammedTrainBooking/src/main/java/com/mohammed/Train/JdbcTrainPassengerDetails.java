package com.mohammed.Train;

import java.io.IOException;

import java.sql.SQLException;
import java.util.Scanner;

public class JdbcTrainPassengerDetails {

	public static void main(String[] args) throws SQLException, IOException {
		
		Scanner scanner=new Scanner(System.in);
		while(true) {
			System.out.println("enter menu details");
			System.out.println("*********************************");
			System.out.println("1. DISPLAY RECORD");
			System.out.println("2. ADD PASSENGER RECORD");
			System.out.println("3. UPDATE PASSENGER RECORD");
			System.out.println("4. DELETE PASSENGER RECORD");
			System.out.println("Enter your choice");
			int choice=scanner.nextInt();
			switch(choice)
			{
			case 1: JdbcAllOperation.displayRecordTrain();
			        JdbcAllOperation.displayRecordPassenger();
			        break;
			
			case 2: JdbcAllOperation.addRecord();
			        break;
			
			case 3: JdbcAllOperation.updateRecord();
			        break;
			
			case 4: JdbcAllOperation.deleteRecord();
			        break;
			default:
				System.out.println("Invalid choice");
			}
			System.out.println("Do you want to continue? y/n");
			char ch=scanner.next().toLowerCase().charAt(0);
			if(ch=='n')
				break;
			}
		System.out.println("program is terminated");
	}
	}