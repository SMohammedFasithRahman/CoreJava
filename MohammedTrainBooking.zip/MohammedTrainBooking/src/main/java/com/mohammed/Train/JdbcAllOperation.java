package com.mohammed.Train;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class JdbcAllOperation {
	private static Connection con;
	private static PreparedStatement pst;
	private static ResultSet rs;
	private static Scanner scanner;
	private static String passname;
	private static int passid;
	private static int passage;
	private static int trnno;
	private static String passemail;
	private static String passphno;
	private static String passaddress;
	private static String passgender;
	private static BufferedReader br;
	
	public static void displayRecordTrain() throws SQLException {
		con = DatabaseConnection.getConnection();
		String sql="select * from train";
		pst=con.prepareStatement(sql);
		rs=pst.executeQuery();
		System.out.println("************************ TRAIN DETAILS **************************");
		System.out.println("                ");
		System.out.println("TRNNO\t\t\tTRNNAME\t\t\tTRNDEPTNAME\t\t\tTRNARRFROM\t\t\tTRNTKT");
		while(rs.next()) {
 System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t\t"+rs.getFloat(3)+"\t\t\t"+rs.getString(4)+"\t\t"+rs.getString(5));
		}
	}

	public static void displayRecordPassenger() throws SQLException {
		con = DatabaseConnection.getConnection();
		String sql="select * from passengers";
		pst=con.prepareStatement(sql);
		rs=pst.executeQuery();
		System.out.println("                     ");
		System.out.println("                     ");
		System.out.println(" ******************* PASSENGER DETAILS **************************");
		System.out.println("                     ");
		System.out.println("PASSID\t\tPASSNAME\t\tPASSAGE\t\tPASSGEND\t\tPASSPHNO\t\t\tPASSEMAIL\t\t\tPASSADDRESS\t\t\tTRNNO");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t"+rs.getInt(3)+"\t\t"+rs.getString(4)+"\t\t"+rs.getString(5)+"\t\t"+rs.getString(6)+"\t\t\t"+rs.getString(7)+"\t\t\t"+rs.getInt(8));
		}
		
		}
	public static void addRecord() throws SQLException, IOException {
		System.out.println("Display record before insertion");
		displayRecordPassenger();
		con = DatabaseConnection.getConnection();
		scanner=new Scanner(System.in);
		System.out.println("enter passenger id");
		passid=scanner.nextInt();
		br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter passenger name");
		passname=br.readLine();
		System.out.println("enter passenger gender");
		passgender=scanner.next();
		System.out.println("enter passenger phone number");
		passphno=br.readLine();
		System.out.println("enter passenger email id");
		passemail=br.readLine();
		System.out.println("enter passenger address");
		passaddress=br.readLine();
		System.out.println("enter train number");
		trnno=scanner.nextInt();
		String sql="select * from passenger where passid =?";
		pst=con.prepareStatement(sql);
		pst.setInt(1, passid);
		rs=pst.executeQuery();
if(!rs.next()) {
	String ins= "insert into passengers values(?,?,?,?,?,?,?,?)";
	pst= con.prepareStatement(ins);
	pst.setInt(1, passid);
	pst.setString(2, passname);
	pst.setInt(3, passage);
	pst.setString(4, passgender);
	pst.setString(5, passphno);
	pst.setString(6, passemail);
	pst.setString(7, passaddress);
	pst.setInt(8, trnno);
	int retval=pst.executeUpdate();
	if(retval>0)
	{
		System.out.println("Passenger record inserted successfully");
		System.out.println("display record after insertion");
		displayRecordPassenger();
	}
	else {
		System.out.println("error occured");
	}
}
else {
	System.out.println(passid+" passenger id already available");
}
	}
	
	public static void updateRecord() throws SQLException,IOException {
		con = DatabaseConnection.getConnection();
		scanner=new Scanner(System.in);
		br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the passengers choice to update");
		System.out.println("*****************************");
		System.out.println("1. Passengers name to change");
		System.out.println("2. Passengers email to change");
		System.out.println("3. Passengers phone number to change");
		System.out.println("4. Passengers address to change");
		scanner=new Scanner(System.in);
		int choose=scanner.nextInt();
		switch(choose) {
		//update passenger name
		case 1: System.out.println("display record before updation");
		displayRecordPassenger();
		System.out.println("Enter passengers name to change");
		passname=br.readLine();
		System.out.println("Enter passengers id to change");
		passid=scanner.nextInt();
		String sel="select * from passengers where passid=?";
		pst=con.prepareStatement(sel);
		pst.setInt(1, passid);
		rs=pst.executeQuery();
		if(rs.next()) {
			String upt="update passengers set passname=? where passid=?";
			pst=con.prepareStatement(upt);
			pst.setString(1, passname);
			pst.setInt(2, passid);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("Passengers name is updated");
				System.out.println("display record after updation");
				displayRecordPassenger();
			}
			else {
				System.out.println("Error Occured");
			}
		}
		else {
			System.out.println(passid+" Passengers id not exists");
		}
		 break;
		 //update passenger email
		case 2: System.out.println("display record before updation");
		displayRecordPassenger();
		System.out.println("Enter passengers email to change");
		passemail=br.readLine();
		System.out.println("Enter passengerss id");
		passid=scanner.nextInt();
		String select="select * from passengers where passid=?";
		pst=con.prepareStatement(select);
		pst.setInt(1, passid);
		rs=pst.executeQuery();
		if(rs.next()) {
			String upt="update passengers set passemail=? where passid=?";
			pst=con.prepareStatement(upt);
			pst.setString(1, passemail);
			pst.setInt(2, passid);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("Passengers email id is updated");
				System.out.println("display record after updation");
				displayRecordPassenger();
			}
			else {
				System.out.println("Error Occured");
			}
		}
		else {
			System.out.println(passid+" Passengers id not exists");
		}
		
		 break;
		 
		 //change passenger phone number
		case 3: System.out.println("display record before updation");
		displayRecordPassenger();
		System.out.println("Enter passengers phone number to change");
		passphno=br.readLine();
		System.out.println("Enter passengers id");
		passid=scanner.nextInt();
		String select1="select * from passengers where passid=?";
		pst=con.prepareStatement(select1);
		pst.setInt(1, passid);
		rs=pst.executeQuery();
		if(rs.next()) {
			String upt="update passengers set passphno=? where passid=?";
			pst=con.prepareStatement(upt);
			pst.setString(1, passphno);
			pst.setInt(2, passid);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("Passengers phone number is updated");
				System.out.println("display record after updation");
				displayRecordPassenger();
			}
			else {
				System.out.println("Error Occured");
			}
		}
		else {
			System.out.println(passid+" Passengers id not exists");
		}
		
		 break;
		 //change passenger address
		case 4: System.out.println("display record before updation");
			displayRecordPassenger();
			System.out.println("Enter passengers address to change");
			passaddress=br.readLine();
			System.out.println("Enter passengers id");
			passid=scanner.nextInt();
			String select2="select * from passengers where passid=?";
			pst=con.prepareStatement(select2);
			pst.setInt(1, passid);
			rs=pst.executeQuery();
			if(rs.next()) {
				String upt="update passengers set passaddress=? where passid=?";
				pst=con.prepareStatement(upt);
				pst.setString(1, passaddress);
				pst.setInt(2, passid);
				int retval=pst.executeUpdate();
				if(retval>0) {
					System.out.println("Passengers address is updated");
					System.out.println("display record after updation");
					displayRecordPassenger();
				}
				else {
					System.out.println("Error Occured");
				}
			}
			else {
				System.out.println(passid+" Passengers id not exists");
			}
			
			 break;
		 default : System.out.println("Invalid input");
		}
	}	 
	public static void deleteRecord() throws SQLException,IOException {
		System.out.println("display record before deletion");
		displayRecordPassenger();
		con=DatabaseConnection.getConnection();
		scanner=new Scanner(System.in);
		System.out.println("Enter passengers id");
		passid=scanner.nextInt();
		String sel="select * from passengers where passid=?";
		pst=con.prepareStatement(sel);
		pst.setInt(1, passid);
		rs=pst.executeQuery();
		if(rs.next()) {
			String del="delete from passengers where passid=?";
			pst=con.prepareStatement(del);
			pst.setInt(1, passid);
			int ret=pst.executeUpdate();
			if(ret>0) {
				System.out.println("Passengers record with passid "+passid+" is deleted successfully");
				System.out.println("display record after deletion");
				displayRecordPassenger();
			}
			else {
				System.out.println("Error Occured");
			}
		}
		else {
			System.out.println(passid+" Passengers id not exists hence record not deleted");
		}
	}
}